# Script Version: 0.2.4 | Phase 1: Testing
# Description: Verification script for Phase 1 components with strict timing assertions.

import os
import json
import time
import signal
import sys
from pathlib import Path
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from source_manager import SourceManager
from agents import DecomposeTopicAgent

def signal_handler(sig, frame):
    print("\n[INFO] Test execution aborted by user (Ctrl+C).")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def load_config_model():
    """Retrieves the primary model ID from models.json."""
    try:
        if Path("models.json").exists():
            with open("models.json", "r") as f:
                data = json.load(f)
                models = data.get("models", [])
                if models:
                    return models[0]['id']
    except Exception as e:
        print(f"[ERROR] Failed to load models.json: {e}")
    return "google/gemini-2.5-flash-lite"

def test_source_manager_precision():
    print("\n" + "="*50)
    print("TESTING SOURCE MANAGER: HIGH-PRECISION RATE LIMITING")
    print("="*50)
    
    # We use a 1000ms (1.0s) delay for unambiguous verification
    delay_ms = 1000
    sm = SourceManager(delay_ms=delay_ms)
    url = "https://example.com"
    
    print(f"[STEP 1] Executing initial request to establish baseline...")
    sm.fetch_web_content(url)
    
    print(f"[STEP 2] Executing second request (Must block for >= {delay_ms}ms)...")
    start_perf = time.perf_counter()
    result = sm.fetch_web_content(url)
    end_perf = time.perf_counter()
    
    duration = end_perf - start_perf
    print(f"[RESULT] Request Status: {result['status']}")
    print(f"[RESULT] Measured Blocking Duration: {duration:.6f}s")
    
    # Strict Verification
    threshold = delay_ms / 1000.0
    if duration >= threshold:
        print(f"[SUCCESS] Rate limiting enforced. {duration:.6f}s >= {threshold}s")
    else:
        print(f"[FAILURE] Rate limiting undershot target! {duration:.6f}s < {threshold}s")
        sys.exit(1)

def test_decompose_agent_logic():
    print("\n" + "="*50)
    print("TESTING DECOMPOSE AGENT: LLM INTEGRATION")
    print("="*50)
    
    load_dotenv()
    api_key = os.getenv("OPENROUTER_API_KEY")
    
    if not api_key or api_key == "YOUR_API_KEY_HERE":
        print("[SKIP] OPENROUTER_API_KEY not found in .env. Skipping LLM test.")
        return

    model_id = load_config_model()
    print(f"[INFO] Using model: {model_id}")

    try:
        llm = ChatOpenAI(
            model_name=model_id,
            openai_api_key=api_key,
            openai_api_base="https://openrouter.ai/api/v1",
            timeout=60
        )
        
        agent = DecomposeTopicAgent(llm)
        topic = "The socio-economic impact of fusion energy by 2050"
        
        print(f"[INFO] Requesting decomposition for: '{topic}'")
        questions = agent.run(topic)
        
        print("\n[AGENT OUTPUT]")
        for q in questions:
            print(f"  [{q.get('priority', '0')}] {q.get('question', 'N/A')}")
            
        if len(questions) >= 5:
            print(f"\n[SUCCESS] Agent generated {len(questions)} research questions.")
        else:
            print(f"\n[WARNING] Agent generated fewer than 5 questions ({len(questions)}).")
            
    except Exception as e:
        print(f"[FATAL] DecomposeTopicAgent test failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    print("[START] Phase 1 Core Component Verification")
    test_source_manager_precision()
    test_decompose_agent_logic()
    print("\n[FINISH] All Phase 1 core tests passed.")
